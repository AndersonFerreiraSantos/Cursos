#include <stdio.h>
#include <stdlib.h>

switch (vari�vel)
{
   case constante1:
     Instru��es;
   break;

   case constante2:
     Instru��es;
   break;

   default
     Instru��es;
}


