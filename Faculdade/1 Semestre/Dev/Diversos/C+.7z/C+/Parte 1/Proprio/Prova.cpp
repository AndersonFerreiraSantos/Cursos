#include <stdio.h>

int main(void){
	
	int B, A, C;
	

	B=5;
	A=7;
	
	C=B+A;

	printf("%f",C);
	return 0;
}
