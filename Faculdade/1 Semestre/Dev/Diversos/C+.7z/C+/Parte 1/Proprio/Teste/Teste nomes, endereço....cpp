#include <stdio.h>
#include <stdlib.h>

int main (void){


	printf("nome: Anderosn Ferreira Santos\n");
	printf("Email: Anderson@mail.com\n");
	printf("CPF:000.000.000-80\n");
	
	return 0;
}
