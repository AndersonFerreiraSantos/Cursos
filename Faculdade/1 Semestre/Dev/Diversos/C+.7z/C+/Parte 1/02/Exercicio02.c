#include <stdio.h>
#include <stdlib.h>

int main (void){
	// defini��o das vari�veis, 'int' para inteiro, 'float' para reais.
	float numero;
	
	// inserindo dados na vari�vel n�mero
	numero=2.1;
	
	// impress�o da vari�vel n�mero em tela
	printf("Numero = %f", numero);
	
	return 0;
}
