#include <stdio.h>
#include <stdlib.h>


int main (void){
	
	float m, c;
	
	printf("metros:  ");
	scanf("%f",&m);
	
	c=m*100;
	
	printf("%f",c);
	
	
	
	return 0;
}
