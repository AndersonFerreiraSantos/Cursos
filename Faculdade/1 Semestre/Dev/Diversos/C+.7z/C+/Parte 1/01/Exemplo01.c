// "//" � para deixar a linha comentada

/* � para fazer
um texto
comentado */

// Bibl�otecas padr�es
#include <stdio.h>
#include <stdlib.h>
//Iniciando a fun��o princpal main()
int main (void){
	
	//Imprimindo um texto em tela que usa a fun��o printf(;
	printf("Boa noite! Segue os dados.\n");
		printf("Nome: Anderson Ferreira Santos\n");
	printf("CPF:000.000.000-80\n");
	printf("RG: 0.000.000\n");
	printf("email: ________@mail.com\n");
	printf("telefone fixo: 0000 - 0000\n");
	printf("telefone celular: 0 0000 - 0000\n");
	
	//Rerono da fun��o principal para verificar se o algoritimo esta correto
	return 0;
	//fechamento da fun��o principal
	
}

	
