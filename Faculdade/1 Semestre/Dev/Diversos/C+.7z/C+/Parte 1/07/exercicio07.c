/*
4. Construa um algoritmo que pe�a uma temperatura em graus Celsius (�C), 
transforme e mostre na tela a temperatura em graus Fahrenheit (�F).
R.:
 C=5*(F-32)/9
 9*c =5*(f-32)
 9*c/5=f-32
 f=9*c/5+32
*/

#include <stdio.h>
#include <stdlib.h>

