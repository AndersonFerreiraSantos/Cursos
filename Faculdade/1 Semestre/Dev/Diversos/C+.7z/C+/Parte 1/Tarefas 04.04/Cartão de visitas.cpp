#include <stdio.h>
#include <stdlib.h>

int main (void){

	printf (" ___________________________________\n");
	printf ("|           Casas Santer            |\n");
	printf ("|                                   |\n");
	printf ("|   A melhor construtora da regiao  |\n");
	printf ("|                                   |\n");
	printf ("| Contato: 9 9211-2628              |\n");
	printf ("| Email: casas@mail.com             |\n");
	printf ("|                                   |\n");
	printf ("|     Venha fazer seu orcamento     |\n");
	printf ("|___________________________________|\n");
	
	return 0;
}


