#include <stdio.h>
#include <stdlib.h>

int main (void){
	// defini��o das vari�veis
	float numero;
	
	// entrada de dados
	printf("Digite um numero: ");
	scanf("%f",&numero);
	
	// sa�da de dados
	printf("Numero = %f", numero);
	
	return 0;
}
