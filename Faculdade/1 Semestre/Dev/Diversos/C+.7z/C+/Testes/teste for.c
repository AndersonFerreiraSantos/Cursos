#include <stdio.h>
#include <stdlib.h>



int main(void){
int i=1;

for(i=1;i<=10;i++){
printf("%i\n",i);
}

return 0;
}
