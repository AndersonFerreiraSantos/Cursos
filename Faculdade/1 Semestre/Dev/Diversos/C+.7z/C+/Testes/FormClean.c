#include <stdio.h>
#include <stdlib.h>

int main (void){
	
	char op;
	
	system("cls");
	
	do{
		
		







		
printf("\n Vodeseja continuar (s/n)? ");
scanf("%c",&op);
fflush(stdin);		
		
	}while(op!='s');
	return 0;
}
