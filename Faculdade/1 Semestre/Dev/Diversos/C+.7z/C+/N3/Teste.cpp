#include <stdio.h>
#include <stdlib.h>


int main (void){
	
	int a;
	float b;
	
	b=2,4;
	a=3;
	b=a;
	
	printf("valor � %i",b);
	
}
