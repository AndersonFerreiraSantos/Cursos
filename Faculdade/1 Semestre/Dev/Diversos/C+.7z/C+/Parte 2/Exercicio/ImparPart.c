#include <stdio.h>
#include<stdlib.h>

int main (void){
	
	int n;
	
	printf ("Digite um numero:  ");
	scanf("%i",&n);
	fflush(stdin);
	
/*	if(n % 2 == 0){
		printf("numero e par");
	}else{
		printf("numero impar");
	}
*/	
print("%f");

	return 0;
}
