int main (void){
	
	int r;
	
	if (r%10==0){
		r*=2;
	}else{
		r-=25;
	}
	printf("%i",r);
	return 0;
}
