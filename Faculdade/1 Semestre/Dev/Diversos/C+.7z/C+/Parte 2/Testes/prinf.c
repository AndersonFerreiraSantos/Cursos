#include <stdio.h>
#include <stdlib.h>

int main (void){
	int a, b, c;
	
	
	a=2;
	b=3;
	c=4;
	
	printf("%i,%i, %i", a, b, c);
	
	return 0;
}
