#include <stdio.h>
#include <stdlib.h>
#include <math.h>

 

int main (void){
    
    int i=1;
    
    do{
        
        i++;
        printf("Numero: %i\n", i);
    
    }while(i!=10);
    
    
    
}
