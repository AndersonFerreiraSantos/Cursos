#include <stdio.h>
#include <stdlib.h>

 

 

int main(void){

 

int i;
int vetor[9];

 

for(i=0;i<=9;i++){
    vetor[i]=i;
    printf("numero[%d]\n",vetor[i]);
}

 

return 0;
}
